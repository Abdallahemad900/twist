# TWIST — all six cans, version 2

## Deliverables

- `Twist_All_Six_v2.blend`: all six editable can assemblies. Opens on the complete lineup, with a separate Blueberry hero scene.
- `models/*.glb`: six complete **wet** models, plus six **dry** models. Every model has the corrected logo and the same back artwork. Images are embedded.
- `web/`: Arabic/English React website with **13 sections**, a rotating Blueberry Island hero, and the all-six model explorer in **section five**. Includes front/back, wet/dry/animated water, density and rotation controls, 12 model downloads, and a complete model ZIP. See `web/README.md` for the section map and animation stack.
- `web/src/TwistCan.tsx`: reusable loader component.
- `web/src/Condensation.tsx`: adjustable instanced water-drop effect.
- `renders/`: front lineup, back lineup, and Blueberry close-up.
- `assets/`: supplied logo/back references and the corrected editable SVG logo.
- `textures/`: six corrected front label wraps.

## Models

| Flavour | Water droplets included | Clean base for animated effect |
|---|---|---|
| Original | `original.glb` | `original_dry.glb` |
| Blueberry Island | `blueberry_island.glb` | `blueberry_island_dry.glb` |
| Coconutberry | `coconutberry.glb` | `coconutberry_dry.glb` |
| Mango Peach | `mango_peach.glb` | `mango_peach_dry.glb` |
| Strawberry | `strawberry.glb` | `strawberry_dry.glb` |
| Power Craze | `power_craze.glb` | `power_craze_dry.glb` |

Dimensions: approximately 53 mm diameter × 134 mm high. In GLB/Three.js: **Y up, front +Z, base y=0**, with metre units. Use `scale={10}` to make the can 1.34 units tall; the effect scales with the same parent group.

## Run the viewer

Use Node.js 22.12+ and npm 10.5+ (tested using Node 24.19). In `web`:

```sh
npm install
npm run dev
```

Open the localhost URL printed by Vite. `npm run build` creates `web/dist`, a static build you can host. The local preview is not a deployed website.

## Add to an existing React Three Fiber website

Install compatible React/R3F versions; this example uses React 19 and Fiber 9. Copy `models` into your site's `public/models` folder, and copy `TwistCan.tsx`, `Condensation.tsx`, and `lib/flavours.ts` into your source tree with the same relative paths. These components run inside your existing `<Canvas>`.

```tsx
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Environment, Lightformer } from '@react-three/drei'
import { TwistCan, flavours } from './TwistCan'

export function AllSix() {
  return (
    <Canvas camera={{ position: [0, .14, .60], fov: 32, near: .001 }}>
      <ambientLight intensity={.3} />
      <directionalLight position={[1,2,3]} intensity={2} />
      <Environment resolution={128}>
        <Lightformer position={[-2,1,3]} scale={[2,4,1]} intensity={3} />
        <Lightformer position={[2,1,2]} scale={[1,4,1]} intensity={2} />
      </Environment>
      {flavours.map((f, i) => (
        <TwistCan key={f.id} flavour={f.id} water="animated"
          position={[(i-2.5)*.079,0,0]} dropCount={420} seed={923+i} />
      ))}
      <OrbitControls target={[0,.067,0]} />
    </Canvas>
  )
}
```

In Next.js, put the Canvas integration in a client component (`'use client'`). The standalone Vite demo does not need that directive.

### Water modes

- `water="static"`: loads the wet GLB with 420 modeled beads. No custom animation code is needed. Suitable for Three.js GLTFLoader and other glTF viewers supporting material transmission.
- `water="animated"`: loads the dry GLB and adds one instanced bead mesh. Most beads stay attached; 18 slowly run down the surface and wrap back to the top. Density is adjustable through `dropCount` (0–2000).
- `water="off"`: loads the dry GLB.

Do not add the animated layer to a wet GLB, or the droplets will double up. The supplied component selects the correct file automatically. Water uses IOR 1.333, a shallow bead shape, and physical transmission. It is a visual condensation effect, not a fluid simulation. Set animation off when respecting reduced motion in your own product. Lower `dropCount` and device pixel ratio on mobile; `transmission={false}` removes refraction from the dynamic effect for a cheaper glossy alternative. An environment map or the included Lightformers is needed for useful reflections.

## Artwork changes and source limits

The lightning bolt was redrawn from the supplied flat logo, with distinct gaps from W and S and its taller/thinner reference proportions. The other labels retain the requested flavour colours. Every can uses the **same unchanged supplied back photograph**, mapped onto the cylindrical surface. This includes its Arabic, QR code, barcode and `SAUDI MADE` mark, exactly as requested. The photograph shows only part of a curved label, so off-camera content cannot be recovered; no substitute small print was invented. The front lettering remains a vector reconstruction from photos, not an official packaging master.

The photographic back is embedded as WebP through `EXT_texture_webp`; the tested Three.js GLTFLoader handles it. Wet materials use `KHR_materials_transmission` and `KHR_materials_ior`. All six wet files are about 2.1 MB each. Each dry model has 32,384 triangles; the wet models add a removable `Condensation` mesh. The Blender noise detail does not transfer, while the physical water geometry does.

## Validation and references

`model-verification.json` records file sizes, embedded images, triangle counts and an identical SHA-256 for the back texture in all 12 files. `verify_models.py` checks centered origins, wet/dry contents and transmission materials. The original V2 viewer was inspected in the browser using static, dry, animated, front and back modes. The later 13-section redesign passes TypeScript, production build, and server-rendered bilingual content checks. Its browser visual/WebGL verification was blocked by the browser tool's URL policy; see `web/verification.json`.

Implementation references: [R3F hooks and model loading](https://r3f.docs.pmnd.rs/api/hooks), [Three.js InstancedMesh](https://threejs.org/docs/pages/InstancedMesh.html), [Three.js physical materials](https://threejs.org/docs/pages/MeshPhysicalMaterial.html).
